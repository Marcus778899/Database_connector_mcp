import os
import logging
from datetime import datetime
from .format import ColorFormatter, PlainFormatter

def get_file_handler(level: str, log_dir: str, base_format: str):
    """File handler — 1 file per level, no colors."""
    current_day = datetime.now().strftime("%Y-%m-%d")
    save_path = os.path.join(log_dir, current_day)

    os.makedirs(save_path, exist_ok=True)

    file_path = os.path.join(save_path, f"{level}.log")
    handler = logging.FileHandler(file_path, encoding="utf-8")

    target_level = logging._nameToLevel[level]
    handler.setLevel(target_level)
    handler.addFilter(lambda record: record.levelno == target_level)

    formatter = PlainFormatter(base_format, "%Y-%m-%d %H:%M:%S")
    handler.setFormatter(formatter)

    return handler

def get_console_handler(base_format: str, level="INFO"):
    """Console handler — Adds colors."""
    formatter = ColorFormatter(base_format, "%Y-%m-%d %H:%M:%S")

    handler = logging.StreamHandler()
    handler.setLevel(level)
    handler.setFormatter(formatter)

    return handler
