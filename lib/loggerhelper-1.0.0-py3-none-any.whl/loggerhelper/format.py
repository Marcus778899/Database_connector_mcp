import logging

class Color:
    RESET = "\033[0m"
    BOLD = "\033[1m"

    GREY = "\033[90m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    CRITICAL_RED = "\033[91m" 

LEVEL_COLORS = {
    "DEBUG": Color.GREY,
    "INFO": Color.GREEN,
    "WARNING": Color.YELLOW,
    "ERROR": Color.RED,
    "CRITICAL": Color.CRITICAL_RED,
}

class ColorFormatter(logging.Formatter):
    """Console formatter — Adds color but does NOT modify record attributes."""

    def format(self, record):
        original = super().format(record)

        color = LEVEL_COLORS.get(record.levelname, "")

        colored = original.replace(
            f"-{record.levelname}-",
            f"-{color}{record.levelname}{Color.RESET}-"
        )

        timestamp = self.formatTime(record, self.datefmt)
        colored = colored.replace(
            f"[{timestamp}]",
            f"[{color}{timestamp}{Color.RESET}]"
        )

        return colored

class PlainFormatter(logging.Formatter):
    """File formatter — No colors."""
    pass

        