import logging
import uuid
import functools
from pathlib import Path
from traceback import format_exc

from .handler import get_console_handler, get_file_handler


class Logger:

    def __init__(self, log_dir: str = None, level="INFO"):
        """
        log_dir: custom log directory for users. If None, auto-detected from project root.
        level: log level ("INFO", "WARNING", "ERROR", "CRITICAL")
        """
        
        if log_dir is None:
            log_dir = self._detect_log_dir()

        self.log_dir = log_dir
        self._logger = logging.getLogger(f"loggerhelper-{uuid.uuid4().hex[:6]}")
        self._logger.setLevel(level)

        process_guid = uuid.uuid4().hex[:4]

        base_format = "[%(asctime)s]-%(levelname)s-(" + process_guid + ")=> %(message)s"

        # Console (colored)
        self._logger.addHandler(get_console_handler(base_format, level))

        # File handlers (no color)
        for lvl in ("INFO", "WARNING", "ERROR", "CRITICAL"):
            self._logger.addHandler(
                get_file_handler(lvl, log_dir, base_format)
            )

    def _detect_log_dir(self) -> str:
        """Auto-detect project root and return 'log' directory path."""
        current_path = Path.cwd()
        for parent in [current_path] + list(current_path.parents):
            if (parent / ".venv").exists() or (parent / "pyproject.toml").exists() or (parent / ".git").exists():
                return str(parent / "log")
        return "./log"

    # ------- Logging functions -------

    def info(self, message):
        self._logger.info(message)

    def warn(self, message):
        self._logger.warning(message)

    def critical(self, message):
        self._logger.critical(message)

    # Error decorator
    def error(self, func):
        """Decorator that auto logs errors with full traceback."""
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                self._logger.error(f"Error in {func.__name__}: {str(e)}")
                self._logger.error(format_exc())
                return None   # Don't re-raise to avoid duplicate traceback
        return wrapper
