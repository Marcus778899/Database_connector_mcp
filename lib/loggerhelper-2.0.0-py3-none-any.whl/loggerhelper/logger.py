"""
The logger itself -- the only implementation module a consumer needs to read.

Nothing is built until the first line is written, so importing costs nothing and
``@log.catch`` is usable as a decorator at import time.
"""

import atexit
import contextlib
import logging
import threading
import warnings

from ._internal.config import (
    LEVEL_NAMES,
    LoggerConfig,
    check_setting_names,
    level_number,
    load_repo_dotenv,
)
from ._internal.decorators import catch as _catch
from ._internal.format import OriginFilter
from ._internal.handler import get_console_handler, get_file_handler, prune_old_logs
from ._internal.notifiers.slack import create_slack_handler

_STACK_OFFSET = 2


class Logger:
    """
    A colourful console logger that also splits its output into per-level files.

    Construction is free -- no directories, no files, no threads. Instances are
    keyed by ``name``: two with the same name share one set of handlers, which
    is what stops a line being written twice. Accepts every setting
    ``LoggerConfig`` does; see the README.
    """

    def __init__(self, log_dir=None, level=None, name=None, config=None, env=None, **settings):
        check_setting_names(settings, extra=("config", "env"))
        self._explicit_config = config
        self._settings = dict(log_dir=log_dir, level=level, name=name, **settings)
        self._env = env
        self._lock = threading.RLock()
        self._logger = None
        self._config = None
        self._slack_listener = None
        atexit.register(self.close)

    @property
    def config(self):
        """The resolved settings. Reading this builds no handlers."""
        with self._lock:
            if self._config is None:
                if self._explicit_config is not None:
                    self._config = self._explicit_config.replace(**self._settings)
                else:
                    self._config = LoggerConfig.from_env(env=self._env, **self._settings)
            return self._config

    def _resolve(self):
        if self._logger is None:
            with self._lock:
                if self._logger is None:
                    logger, slack_problem = self._build()
                    self._logger = logger
                    if slack_problem:
                        logger.critical("Slack alerts are disabled: %s", slack_problem)
        return self._logger

    def _build(self):
        config = self.config
        logger = logging.getLogger(f"loggerhelper.{config.name}" if config.name else "loggerhelper")
        logger.setLevel(level_number(config.level))
        logger.propagate = False

        for handler in list(logger.handlers):
            logger.removeHandler(handler)
            handler.close()
        for existing in list(logger.filters):
            logger.removeFilter(existing)

        logger.addFilter(OriginFilter(config.name))

        prune_old_logs(config.log_dir, config.retention_days)
        logger.addHandler(get_console_handler(config))
        for level_name in LEVEL_NAMES:
            logger.addHandler(get_file_handler(level_name, config))

        slack = create_slack_handler(config)
        if slack is not None:
            handler, listener = slack
            self._slack_listener = listener
            logger.addHandler(handler)

        return logger, config.slack_problem()

    def reconfigure(self, config=None, env=None, **settings):
        """
        Change settings. Values of ``None`` mean "leave as is".

        Doing this after logging has started is noted in the log: earlier lines
        went somewhere else.
        """
        check_setting_names(settings, extra=("config", "env", "load_dotenv"))
        with self._lock:
            started = self._logger is not None
            if config is not None:
                self._explicit_config = config
                self._settings = {}
            else:
                self._settings.update({k: v for k, v in settings.items() if v is not None})
            if env is not None:
                self._env = env
            self._config = None

        if started:
            self.close()
            self.warning("logger reconfigured after use; handlers were rebuilt")
        return self

    def close(self):
        """Release files and stop the Slack thread. Logging again rebuilds."""
        with self._lock:
            listener, self._slack_listener = self._slack_listener, None
            logger, self._logger = self._logger, None

        if listener is not None:
            with contextlib.suppress(Exception):
                listener.stop()
        if logger is not None:
            for handler in list(logger.handlers):
                logger.removeHandler(handler)
                handler.close()

    def _emit(self, level, message, *args, **kwargs):
        """
        stacklevel is what makes ``origin`` point at the caller rather than at
        this file. Every public method must sit exactly one frame above here.
        """
        kwargs["stacklevel"] = kwargs.pop("stacklevel", 1) + _STACK_OFFSET
        self._resolve().log(level, message, *args, **kwargs)

    def debug(self, message, *args, **kwargs):
        """Detail only useful while working on the code."""
        self._emit(logging.DEBUG, message, *args, **kwargs)

    def info(self, message, *args, **kwargs):
        """A normal lifecycle event: started, connected, finished."""
        self._emit(logging.INFO, message, *args, **kwargs)

    def warning(self, message, *args, **kwargs):
        """Degraded, but this operation still succeeded."""
        self._emit(logging.WARNING, message, *args, **kwargs)

    def error(self, message, *args, **kwargs):
        """
        This operation failed; the service is still running.

        Also accepts a function, for compatibility with the first version where
        ``error`` was the decorator. That use is deprecated.
        """
        if callable(message) and not args and not kwargs:
            warnings.warn(
                "@logger.error as a decorator is deprecated. Use @logger.catch, which "
                "re-raises, or @logger.catch(reraise=False) to keep swallowing the "
                "exception as before.",
                DeprecationWarning,
                stacklevel=2,
            )
            return self.catch(message, reraise=False)
        self._emit(logging.ERROR, message, *args, **kwargs)
        return None

    def critical(self, message, *args, **kwargs):
        """The process or service cannot continue."""
        self._emit(logging.CRITICAL, message, *args, **kwargs)

    def exception(self, message, *args, **kwargs):
        """``error`` with the active traceback attached. Use inside ``except``."""
        kwargs.setdefault("exc_info", True)
        self._emit(logging.ERROR, message, *args, **kwargs)

    def log(self, level, message, *args, **kwargs):
        """Log at a level chosen at runtime, e.g. ``log.log("WARNING", msg)``."""
        self._emit(level_number(level), message, *args, **kwargs)

    def warn(self, message, *args, **kwargs):
        """Deprecated alias for warning()."""
        warnings.warn(
            "Logger.warn() is deprecated; use Logger.warning().",
            DeprecationWarning,
            stacklevel=2,
        )
        self._emit(logging.WARNING, message, *args, **kwargs)

    def _emit_failure(self, level, message, exc):
        self._resolve().log(level_number(level), message, exc_info=exc, stacklevel=3)

    def catch(self, func=None, level="ERROR", reraise=True, default=None, exclude=()):
        """
        Log any exception escaping the decorated function, then re-raise it.

        ``ERROR`` by default because an exception escaping a function means that
        operation failed, whatever the function does. Reserve ``CRITICAL`` for
        start-up paths where the failure ends the process.

            @log.catch
            def handle(request): ...

            @log.catch(level="CRITICAL")
            def load_config(): ...

            @log.catch(reraise=False, default=[])
            def optional_extras(): ...

        Works on ``async def``. Decorating does not build the logger.
        """
        return _catch(
            self._emit_failure,
            func,
            level=level,
            reraise=reraise,
            default=default,
            exclude=exclude,
        )


log = Logger()


def configure(
    log_dir=None, level=None, name=None, config=None, env=None, load_dotenv=False, **settings
):
    """
    Point the shared logger somewhere. Everything is optional.

        configure(log_dir="./logs")

    Call it before the first log line. ``load_dotenv=True`` applies the nearest
    ``.env`` first; it is off by default because a library should not edit the
    environment behind the application's back.
    """
    if load_dotenv:
        load_repo_dotenv()
    return log.reconfigure(
        config=config, env=env, log_dir=log_dir, level=level, name=name, **settings
    )
