"""
LoggerHelper -- coloured console output, per-level log files, and an error
decorator that names the definition that failed.

Import the shared logger and write::

    from loggerhelper import log

    log.info("System started")
    log.error("could not reach the queue")

    @log.catch
    def handle(request): ...

Nothing is created until the first line is logged, so importing this costs
nothing and ``@log.catch`` is safe to apply at import time. Settings come from
the environment (``LOG_DIR``, ``LOG_LEVEL``, ``SLACK_WEBHOOK_URL`` and friends)
or from ``configure()``::

    from loggerhelper import configure
    configure(log_dir="./logs")

Everything else lives in ``loggerhelper._internal`` and may change between
releases; the names below are the ones that will not.
"""

from ._internal.config import ConfigError, LoggerConfig
from .logger import Logger, configure, log

__all__ = [
    "ConfigError",
    "Logger",
    "LoggerConfig",
    "configure",
    "log",
]

__version__ = "2.0.0"
