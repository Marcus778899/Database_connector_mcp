"""
Implementation detail. Nothing here is part of the public API.

Consumers import from ``loggerhelper``; the layout inside may change in any
release. Modules here may import each other, never ``loggerhelper.logger``.
"""
