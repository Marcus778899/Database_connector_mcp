"""
Slack alerts, by incoming webhook or by bot token.

Logging must never block the caller, so the POST happens on a background thread
behind a bounded queue. An error loop must not flood the channel, so repeats are
collapsed into a count. Sending nothing beats raising: a broken webhook is not
the application's problem to handle.
"""

import atexit
import json
import logging
import logging.handlers
import queue
import sys
import threading
import time
import traceback
import urllib.request

from ..config import level_number

CHAT_POST_MESSAGE_URL = "https://slack.com/api/chat.postMessage"

MAX_TEXT_CHARS = 2800
DEFAULT_THROTTLE_SECONDS = 60.0
DEFAULT_MAX_PER_MINUTE = 20
DEFAULT_TIMEOUT = 5.0
QUEUE_SIZE = 1000

LEVEL_COLORS = {
    "WARNING": "#d9a441",
    "ERROR": "#d64541",
    "CRITICAL": "#8b1a1a",
}


def _truncate(text, limit=MAX_TEXT_CHARS):
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n... [{len(text) - limit} more characters]"


class SlackHandler(logging.Handler):
    """Runs on the listener thread, so it is allowed to be slow."""

    def __init__(
        self,
        webhook_url=None,
        bot_token=None,
        channel=None,
        environment=None,
        service=None,
        throttle_seconds=DEFAULT_THROTTLE_SECONDS,
        max_per_minute=DEFAULT_MAX_PER_MINUTE,
        timeout=DEFAULT_TIMEOUT,
    ):
        super().__init__()
        if webhook_url and bot_token:
            raise ValueError("give a webhook URL or a bot token, not both")
        if not webhook_url and not bot_token:
            raise ValueError("a webhook URL or a bot token is required")
        if webhook_url and not webhook_url.startswith("https://"):
            raise ValueError("Slack webhook URL must be https://")
        if bot_token and not channel:
            raise ValueError("a bot token needs a channel to post to")
        self.webhook_url = webhook_url
        self.bot_token = bot_token
        self.channel = channel
        self.environment = environment
        self.service = service
        self.throttle_seconds = throttle_seconds
        self.max_per_minute = max_per_minute
        self.timeout = timeout

        self._lock = threading.Lock()
        self._last_sent = {}
        self._suppressed = {}
        self._window_start = time.monotonic()
        self._window_count = 0
        self._window_dropped = 0
        self._reported_failure = False

    @staticmethod
    def _key(record):
        return (
            record.levelname,
            getattr(record, "origin", record.name),
            getattr(record, "exc_type", ""),
        )

    def _admit(self, record, now):
        """How many repeats were folded in, or None to stay quiet."""
        key = self._key(record)
        with self._lock:
            if now - self._window_start >= 60.0:
                self._window_start = now
                self._window_count = 0
                self._window_dropped = 0

            last = self._last_sent.get(key)
            if last is not None and now - last < self.throttle_seconds:
                self._suppressed[key] = self._suppressed.get(key, 0) + 1
                return None

            if self._window_count >= self.max_per_minute:
                self._window_dropped += 1
                self._suppressed[key] = self._suppressed.get(key, 0) + 1
                return None

            self._last_sent[key] = now
            self._window_count += 1
            return self._suppressed.pop(key, 0)

    def _payload(self, record, suppressed):
        text = record.getMessage()
        title, _, detail = text.partition("\n")

        fields = []
        if self.environment:
            fields.append({"title": "Environment", "value": self.environment, "short": True})
        if self.service:
            fields.append({"title": "Service", "value": self.service, "short": True})
        origin = getattr(record, "origin", None)
        if origin:
            fields.append({"title": "Origin", "value": f"`{origin}`", "short": False})
        if suppressed:
            fields.append(
                {
                    "title": "Repeats",
                    "value": f"{suppressed} identical message(s) suppressed since the last alert",
                    "short": False,
                }
            )

        attachment = {
            "color": LEVEL_COLORS.get(record.levelname, "#808080"),
            "fallback": _truncate(title, 300),
            "title": f"{record.levelname}: {_truncate(title, 300)}",
            "fields": fields,
            "ts": int(record.created),
        }
        if detail.strip():
            attachment["text"] = f"```{_truncate(detail.strip())}```"

        return {
            "text": f"{record.levelname}: {_truncate(title, 300)}",
            "attachments": [attachment],
        }

    def _post(self, payload):
        """
        A webhook signals failure with the status code, which urlopen raises on.
        chat.postMessage answers 200 with ok:false instead, so a bad channel or
        a missing scope would otherwise look like success.
        """
        headers = {"Content-Type": "application/json; charset=utf-8"}
        if self.bot_token:
            url = CHAT_POST_MESSAGE_URL
            headers["Authorization"] = f"Bearer {self.bot_token}"
            payload = dict(payload, channel=self.channel)
        else:
            url = self.webhook_url

        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=self.timeout) as response:  # nosec B310
            if not self.bot_token:
                return
            body = json.loads(response.read().decode("utf-8") or "{}")
            if not body.get("ok"):
                raise RuntimeError(f"Slack rejected the message: {body.get('error')!r}")

    def emit(self, record):
        try:
            suppressed = self._admit(record, time.monotonic())
            if suppressed is None:
                return
            self._post(self._payload(record, suppressed))
        except Exception:
            self.handleError(record)

    def handleError(self, record):  # noqa: N802
        """Report the first failure and then go quiet; a dead webhook stays dead."""
        with self._lock:
            first = not self._reported_failure
            self._reported_failure = True
        if first:
            print(
                "loggerhelper: Slack notification failed, staying quiet from here:",
                file=sys.stderr,
            )
            traceback.print_exc(file=sys.stderr)


class _DroppingQueueHandler(logging.handlers.QueueHandler):
    """
    Hand records to the listener thread, dropping them if it falls behind.

    An unbounded queue would turn a Slack outage during an error storm into
    unbounded memory growth.
    """

    def __init__(self, q):
        super().__init__(q)
        self.dropped = 0

    def prepare(self, record):
        if record.exc_info and record.exc_info[0] is not None:
            record.exc_type = record.exc_info[0].__name__
        return super().prepare(record)

    def enqueue(self, record):
        try:
            self.queue.put_nowait(record)
        except queue.Full:
            self.dropped += 1


class _IdempotentQueueListener(logging.handlers.QueueListener):
    """Logger.close() stops it and so does atexit; the stdlib raises on the second."""

    def stop(self):
        if getattr(self, "_thread", None) is None:
            return
        super().stop()


def create_slack_handler(config):
    """The queued Slack handler, or None when Slack is not usable."""
    if not config.slack_enabled:
        return None

    target = SlackHandler(
        webhook_url=config.slack_webhook_url,
        bot_token=config.slack_bot_token,
        channel=config.slack_channel,
        environment=config.slack_env,
        service=config.name,
    )
    threshold = level_number(config.slack_level)
    target.setLevel(threshold)

    handler = _DroppingQueueHandler(queue.Queue(maxsize=QUEUE_SIZE))
    handler.setLevel(threshold)
    handler.setFormatter(logging.Formatter("%(message)s"))

    listener = _IdempotentQueueListener(handler.queue, target, respect_handler_level=True)
    listener.start()
    atexit.register(listener.stop)
    return handler, listener
