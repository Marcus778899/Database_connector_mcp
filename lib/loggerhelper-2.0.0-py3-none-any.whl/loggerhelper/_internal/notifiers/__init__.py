"""Optional outbound alerting, attached only when configured."""
