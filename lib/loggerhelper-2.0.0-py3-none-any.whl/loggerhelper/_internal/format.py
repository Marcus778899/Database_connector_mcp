"""Turning a record into a line: the origin field, and colour on a terminal."""

import copy
import logging
import os
import sys
from functools import lru_cache
from pathlib import Path

BASE_FORMAT = "[%(asctime)s]-%(levelname)s-(%(origin)s)=> %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


class Color:
    RESET = "\033[0m"
    GREY = "\033[90m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    CRITICAL_RED = "\033[91m"


LEVEL_COLORS = {
    logging.DEBUG: Color.GREY,
    logging.INFO: Color.GREEN,
    logging.WARNING: Color.YELLOW,
    logging.ERROR: Color.RED,
    logging.CRITICAL: Color.CRITICAL_RED,
}

_MAX_PACKAGE_DEPTH = 10


@lru_cache(maxsize=512)
def _dotted_module(pathname, fallback):
    """``src/service/pool.py`` -> ``service.pool``, cached per source file."""
    try:
        path = Path(pathname)
    except (TypeError, ValueError):
        return fallback
    if path.suffix != ".py":
        return fallback

    directory = path.parent
    parts = [] if path.stem == "__init__" else [path.stem]
    for _ in range(_MAX_PACKAGE_DEPTH):
        try:
            if not (directory / "__init__.py").exists():
                break
        except OSError:
            break
        parts.append(directory.name)
        directory = directory.parent

    return ".".join(reversed(parts)) if parts else fallback


class OriginFilter(logging.Filter):
    """
    Attach ``record.origin`` -- ``module.function:line`` of the call site.

    Correct output depends on the caller passing ``stacklevel``, so the record
    points at user code and not at this package.
    """

    def __init__(self, tag=None):
        super().__init__()
        self.tag = tag

    def filter(self, record):
        module = _dotted_module(record.pathname, record.module)
        origin = f"{module}.{record.funcName}:{record.lineno}"
        record.origin = f"{self.tag}|{origin}" if self.tag else origin
        return True


class PlainFormatter(logging.Formatter):
    """What goes into a file: no escape codes, ever."""


class ColorFormatter(logging.Formatter):
    """
    The console line, with the level and timestamp coloured.

    Colour goes on the fields, and on a copy of the record: the file handlers
    format the same object and must not see the escape codes.
    """

    def __init__(self, fmt=None, datefmt=None, use_color=True):
        super().__init__(fmt, datefmt)
        self.use_color = use_color

    def format(self, record):
        color = LEVEL_COLORS.get(record.levelno, "") if self.use_color else ""
        if not color:
            return super().format(record)
        clone = copy.copy(record)
        clone.levelname = f"{color}{record.levelname}{Color.RESET}"
        return super().format(clone)

    def formatTime(self, record, datefmt=None):  # noqa: N802
        stamp = super().formatTime(record, datefmt)
        color = LEVEL_COLORS.get(record.levelno, "") if self.use_color else ""
        return f"{color}{stamp}{Color.RESET}" if color else stamp


def _enable_windows_ansi():
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32
        for stream_id in (-11, -12):
            handle = kernel32.GetStdHandle(stream_id)
            mode = ctypes.c_uint32()
            if not kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                return False
            kernel32.SetConsoleMode(handle, mode.value | 0x4)
        return True
    except Exception:
        return False


def should_use_color(mode, stream=None):
    """``always``/``never`` at face value; ``auto`` asks the stream."""
    if mode == "never":
        return False
    if mode == "auto":
        if os.environ.get("NO_COLOR"):
            return False
        stream = sys.stderr if stream is None else stream
        try:
            if not stream.isatty():
                return False
        except (AttributeError, ValueError):
            return False
    if sys.platform == "win32":
        return _enable_windows_ansi()
    return True
