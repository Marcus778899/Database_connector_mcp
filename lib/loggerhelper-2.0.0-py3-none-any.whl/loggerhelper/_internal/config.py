"""Settings resolution: explicit argument, then environment, then default."""

import difflib
import os
from pathlib import Path

DEFAULT_LEVEL = "INFO"
DEFAULT_MAX_BYTES = 50 * 1024 * 1024
DEFAULT_BACKUP_COUNT = 5
DEFAULT_RETENTION_DAYS = 30
DEFAULT_SLACK_LEVEL = "WARNING"

LEVEL_NAMES = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")

ENV_KEYS = {
    "log_dir": "LOG_DIR",
    "level": "LOG_LEVEL",
    "name": "LOG_NAME",
    "max_bytes": "LOG_MAX_BYTES",
    "backup_count": "LOG_BACKUP_COUNT",
    "retention_days": "LOG_RETENTION_DAYS",
    "color": "LOG_COLOR",
    "slack_webhook_url": "SLACK_WEBHOOK_URL",
    "slack_bot_token": "SLACK_BOT_TOKEN",
    "slack_channel": "SLACK_CHANNEL",
    "slack_level": "SLACK_LOG_LEVEL",
    "slack_env": "SLACK_ENV",
}

_LEVEL_NUMBERS = {"DEBUG": 10, "INFO": 20, "WARNING": 30, "ERROR": 40, "CRITICAL": 50}
_LEVEL_ALIASES = {"WARN": "WARNING", "FATAL": "CRITICAL"}
_COLOR_MODES = ("auto", "always", "never")


class ConfigError(ValueError):
    """A setting was given, but not in a form that can be used."""


def normalise_level(value, source="level"):
    name = str(value).strip().upper()
    name = _LEVEL_ALIASES.get(name, name)
    if name not in _LEVEL_NUMBERS:
        raise ConfigError(
            f"{source}={value!r} is not a log level. Use one of: {', '.join(LEVEL_NAMES)}"
        )
    return name


def level_number(value):
    return _LEVEL_NUMBERS[normalise_level(value)]


def detect_log_dir(start=None):
    """Put ``log/`` at the project root, found by walking up from the cwd."""
    current = Path.cwd() if start is None else Path(start)
    for parent in [current, *current.parents]:
        for marker in (".venv", "pyproject.toml", ".git"):
            if (parent / marker).exists():
                return str(parent / "log")
    return str(current / "log")


def _as_int(raw, source):
    try:
        return int(raw.strip())
    except ValueError:
        raise ConfigError(f"{source}={raw!r} must be a whole number") from None


_CASTS = {"max_bytes": _as_int, "backup_count": _as_int, "retention_days": _as_int}


class LoggerConfig:
    """Everything a Logger needs, already validated. See the README for each setting."""

    SETTINGS = (
        "log_dir",
        "level",
        "name",
        "max_bytes",
        "backup_count",
        "retention_days",
        "color",
        "slack_webhook_url",
        "slack_bot_token",
        "slack_channel",
        "slack_level",
        "slack_env",
    )

    _SECRETS = ("slack_webhook_url", "slack_bot_token")

    def __init__(
        self,
        log_dir=None,
        level=DEFAULT_LEVEL,
        name=None,
        max_bytes=DEFAULT_MAX_BYTES,
        backup_count=DEFAULT_BACKUP_COUNT,
        retention_days=DEFAULT_RETENTION_DAYS,
        color="auto",
        slack_webhook_url=None,
        slack_bot_token=None,
        slack_channel=None,
        slack_level=DEFAULT_SLACK_LEVEL,
        slack_env=None,
    ):
        self.log_dir = str(detect_log_dir() if log_dir is None else log_dir)
        self.level = normalise_level(level, source="level")
        self.slack_level = normalise_level(slack_level, source="slack_level")
        self.name = name
        self.slack_env = slack_env

        mode = str(color).strip().lower()
        if mode not in _COLOR_MODES:
            raise ConfigError(f"color={color!r} must be one of: {', '.join(_COLOR_MODES)}")
        self.color = mode

        for attr, value in (
            ("max_bytes", max_bytes),
            ("backup_count", backup_count),
            ("retention_days", retention_days),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ConfigError(f"{attr}={value!r} must be a whole number >= 0")
            setattr(self, attr, value)

        self.slack_webhook_url = slack_webhook_url.strip() or None if slack_webhook_url else None
        self.slack_bot_token = slack_bot_token.strip() or None if slack_bot_token else None
        self.slack_channel = slack_channel.strip() or None if slack_channel else None

    def _shown(self, name):
        value = getattr(self, name)
        return "***" if value and name in self._SECRETS else repr(value)

    def __repr__(self):
        shown = ", ".join(f"{name}={self._shown(name)}" for name in self.SETTINGS)
        return f"LoggerConfig({shown})"

    def slack_problem(self):
        """
        Why Slack cannot be used, as a sentence, or None if it can.

        Reported rather than raised: a mistake in an optional notifier must not
        stop the program from logging. Never quotes a value back -- two of the
        three are credentials.
        """
        url, token = self.slack_webhook_url, self.slack_bot_token
        if url and token:
            return (
                "SLACK_WEBHOOK_URL and SLACK_BOT_TOKEN are two different ways to reach "
                "Slack and they name different destinations; set one, not both"
            )
        if url and not url.startswith("https://"):
            return "SLACK_WEBHOOK_URL must start with https://"
        if token and not token.startswith("xox"):
            return (
                "SLACK_BOT_TOKEN does not look like a bot token; it should start with "
                "'xoxb-'. The Basic Information page has no bot token on it -- find it "
                "under OAuth & Permissions -> Bot User OAuth Token"
            )
        if token and not self.slack_channel:
            return "SLACK_BOT_TOKEN needs SLACK_CHANNEL; a token can post to any channel"
        return None

    @property
    def slack_enabled(self):
        """Whether Slack will actually be used. slack_problem() says why not."""
        return bool(self.slack_webhook_url or self.slack_bot_token) and not self.slack_problem()

    def replace(self, **changes):
        """A copy with some settings changed. A change of None is ignored."""
        check_setting_names(changes)
        values = {name: getattr(self, name) for name in self.SETTINGS}
        values.update({k: v for k, v in changes.items() if v is not None})
        return LoggerConfig(**values)

    @classmethod
    def from_env(cls, env=None, **overrides):
        """
        Build from the environment, with overrides winning.

        An override of None means "not given" and falls through to the
        environment, so callers can forward optional arguments without branching.
        """
        env = os.environ if env is None else env
        values = {}
        remaining = dict(overrides)

        for field_name, env_key in ENV_KEYS.items():
            given = remaining.pop(field_name, None)
            if given is not None:
                values[field_name] = given
                continue
            raw = env.get(env_key)
            if raw is None or not raw.strip():
                continue
            cast = _CASTS.get(field_name)
            values[field_name] = cast(raw, env_key) if cast else raw.strip()

        check_setting_names(remaining)
        return cls(**values)


def check_setting_names(names, extra=()):
    """
    Reject unknown setting names, suggesting a near miss.

    Called from Logger() and configure() rather than where settings are
    resolved: resolution is lazy, so otherwise a typo surfaces at the first log
    call and the traceback points at a line that is perfectly correct.
    """
    known = tuple(LoggerConfig.SETTINGS) + tuple(extra)
    unknown = sorted(name for name in names if name not in known)
    if not unknown:
        return

    described = []
    for name in unknown:
        close = difflib.get_close_matches(name, known, n=1)
        described.append(f"{name!r} (did you mean {close[0]!r}?)" if close else repr(name))
    raise ConfigError(
        f"unknown setting(s): {', '.join(described)}. Known settings: {', '.join(known)}"
    )


def parse_dotenv(text):
    """Parse KEY=value lines. No interpolation, no dependency."""
    values = {}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("export "):
            stripped = stripped[len("export ") :].lstrip()
        key, separator, value = stripped.partition("=")
        if not separator:
            continue
        key = key.strip()
        if not key:
            continue
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        values[key] = value
    return values


def load_repo_dotenv(filename=".env", start=None, override=False):
    """
    Apply the nearest .env walking up from the working directory.

    Off unless asked for: a library that edits os.environ on import surprises
    the application that imported it.
    """
    current = Path.cwd() if start is None else Path(start)
    for parent in [current, *current.parents]:
        candidate = parent / filename
        if candidate.is_file():
            for key, value in parse_dotenv(candidate.read_text(encoding="utf-8")).items():
                if override or key not in os.environ:
                    os.environ[key] = value
            return candidate
    return None
