"""One file per level under a dated directory, rotated by size and by day."""

import logging
import logging.handlers
import re
import shutil
from datetime import date, timedelta
from pathlib import Path

from .config import level_number
from .format import BASE_FORMAT, DATE_FORMAT, ColorFormatter, PlainFormatter, should_use_color

_DATE_DIR = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _today():
    return date.today().isoformat()


def prune_old_logs(log_dir, retention_days):
    """
    Delete dated directories older than the window, and return the count.

    Only directories named exactly ``YYYY-MM-DD`` directly under ``log_dir``
    are touched; whatever else is kept there is not ours to remove.
    """
    if retention_days <= 0:
        return 0
    cutoff = date.today() - timedelta(days=retention_days)
    try:
        entries = list(Path(log_dir).iterdir())
    except OSError:
        return 0

    removed = 0
    for entry in entries:
        if not _DATE_DIR.match(entry.name) or not entry.is_dir():
            continue
        try:
            when = date.fromisoformat(entry.name)
        except ValueError:
            continue
        if when < cutoff:
            shutil.rmtree(entry, ignore_errors=True)
            removed += 1
    return removed


class DailyDirRotatingFileHandler(logging.handlers.RotatingFileHandler):
    """
    ``<log_dir>/<YYYY-MM-DD>/<LEVEL>.log``.

    The date is decided when a record is written, so a process that outlives
    midnight rolls over. Opened lazily, so attaching the handler creates nothing.
    """

    def __init__(
        self,
        log_dir,
        level_name,
        max_bytes=0,
        backup_count=0,
        retention_days=0,
        encoding="utf-8",
    ):
        self.log_dir = Path(log_dir)
        self.level_name = level_name
        self.retention_days = retention_days
        self._current_day = _today()
        super().__init__(
            str(self._path_for(self._current_day)),
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding=encoding,
            delay=True,
        )

    def _path_for(self, day):
        return self.log_dir / day / f"{self.level_name}.log"

    def _open(self):
        Path(self.baseFilename).parent.mkdir(parents=True, exist_ok=True)
        return super()._open()

    def shouldRollover(self, record):  # noqa: N802
        if _today() != self._current_day:
            return 1
        return super().shouldRollover(record)

    def doRollover(self):  # noqa: N802
        today = _today()
        if today == self._current_day:
            super().doRollover()
            return

        if self.stream:
            self.stream.close()
            self.stream = None
        self._current_day = today
        self.baseFilename = str(self._path_for(today))
        prune_old_logs(str(self.log_dir), self.retention_days)
        if not self.delay:
            self.stream = self._open()


def get_file_handler(level_name, config):
    handler = DailyDirRotatingFileHandler(
        config.log_dir,
        level_name,
        max_bytes=config.max_bytes,
        backup_count=config.backup_count,
        retention_days=config.retention_days,
    )
    target = level_number(level_name)
    handler.setLevel(target)
    handler.addFilter(lambda record: record.levelno == target)
    handler.setFormatter(PlainFormatter(BASE_FORMAT, DATE_FORMAT))
    return handler


def get_console_handler(config, stream=None):
    handler = logging.StreamHandler(stream)
    handler.setLevel(level_number(config.level))
    handler.setFormatter(
        ColorFormatter(
            BASE_FORMAT,
            DATE_FORMAT,
            use_color=should_use_color(config.color, handler.stream),
        )
    )
    return handler
