"""The ``@catch`` decorator: log an escaping exception, and name where it came from."""

import functools
import inspect
import os


def describe_failure(func, exc):
    """
    ``TypeError in service.pool.AdapterPool.acquire (pool.py:87): ...``

    The line comes from the deepest traceback frame -- where the exception was
    actually raised, not where the decorator sits.
    """
    where = f"{getattr(func, '__module__', '?')}.{getattr(func, '__qualname__', func)}"

    location = ""
    frame = getattr(exc, "__traceback__", None)
    if frame is not None:
        while frame.tb_next is not None:
            frame = frame.tb_next
        filename = os.path.basename(frame.tb_frame.f_code.co_filename)
        location = f" ({filename}:{frame.tb_lineno})"

    return f"{type(exc).__name__} in {where}{location}: {exc}"


def catch(emit, func=None, level="ERROR", reraise=True, default=None, exclude=()):
    """
    Wrap ``func`` so an escaping exception is logged through ``emit``.

    ``emit(level, message, exception)`` is a callable rather than a logger, so
    decorating at import time does not force a logger to be built. Usable bare
    or called, on ``def`` and on ``async def``.
    """

    def decorate(target):
        if inspect.iscoroutinefunction(target):

            @functools.wraps(target)
            async def async_wrapper(*args, **kwargs):
                try:
                    return await target(*args, **kwargs)
                except exclude:
                    raise
                except Exception as exc:
                    emit(level, describe_failure(target, exc), exc)
                    if reraise:
                        raise
                    return default

            return async_wrapper

        @functools.wraps(target)
        def wrapper(*args, **kwargs):
            try:
                return target(*args, **kwargs)
            except exclude:
                raise
            except Exception as exc:
                emit(level, describe_failure(target, exc), exc)
                if reraise:
                    raise
                return default

        return wrapper

    return decorate if func is None else decorate(func)
